*************************************************************************************************************************************************************************
This package contains the source code and dataset used in the following paper:


This demo is implemented by xilai Li (20210300236@fosu.edu.cn).
*************************************************************************************************************************************************************************

Usage:

main.m ----- Implementation of the  Multi-focus image fusion based on the multiscale cross difference and focus detection
